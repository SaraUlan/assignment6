import java.util.Random;
public class Main {
    public static void main(String[] args) {
        MyHashTable<Grade, Student> table = new MyHashTable<>(10000);
//        table.put(new Grade("A"), new Student("Yedige", "Mazhit"));
//        table.put(new Grade("B"), new Student("Yeldar", "Oralgaziev"));
//        table.put(new Grade("C"), new Student("Ansar", "Zheksengaly"));
//        table.put(new Grade("D"), new Student("Alikhan", "Kalibekov"));
        Random rand = new Random();
        for (int i = 0; i < 10000; i++){
            Grade grade = new Grade(Integer.toString(i));
            Student st = new Student("Student %d".formatted(i), "Student %d".formatted(i));
            table.put(grade, st);
        }
        table.printBucketSizes();
    }
}